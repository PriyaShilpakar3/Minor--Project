import { useState, useRef, useCallback, useEffect } from 'react'; 
import { Copy, Edit, Loader2, ArrowLeft, Upload, Volume2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const GenerateCaption = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [caption, setCaption] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedCaption, setEditedCaption] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef(null);
  const dropAreaRef = useRef(null);
  const navigate = useNavigate();

  // Speech synthesis function
  const speakCaption = useCallback(() => {
    if ('speechSynthesis' in window && caption.trim() !== '') {
      const utterance = new SpeechSynthesisUtterance(caption);
      window.speechSynthesis.cancel(); // Cancel any ongoing speech
      window.speechSynthesis.speak(utterance);
    }
  }, [caption]);

  // Auto speak caption whenever it changes
  useEffect(() => {
    speakCaption();
  }, [caption, speakCaption]);

  // Handle file selection
  const handleFile = (file) => {
    if (file && file.type.match('image.*')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle drag events
  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    handleFile(file);
  };

  const generateCaption = () => {
    setIsGenerating(true);
    // Simulate API call
    setTimeout(() => {
      setCaption("This is a beautiful AI-generated caption for your photo! ✨");
      setIsGenerating(false);
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(caption);
    // Optional: Add toast notification instead of alert
    alert('Caption copied to clipboard!');
  };

  const handleEditClick = () => {
    setIsEditing(true);
    setEditedCaption(caption);
  };

  const handleSaveEdit = () => {
    setCaption(editedCaption);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
  };

  const handleGoBack = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <button 
          onClick={handleGoBack}
          className="flex items-center text-blue-500 hover:text-blue-700 mb-6"
        >
          <ArrowLeft className="mr-2" /> Back
        </button>
        
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-8 text-blue-600">
          AI Photo Caption Generator
        </h1>
        
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          {/* Image Upload Section with Drag and Drop */}
          <div className="mb-8">
            <div 
              ref={dropAreaRef}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition ${
                isDragging 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-blue-200 hover:bg-blue-50'
              }`}
              onClick={() => fileInputRef.current.click()}
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                className="hidden"
              />
              {selectedImage ? (
                <div className="flex flex-col items-center">
                  <img 
                    src={selectedImage} 
                    alt="Selected" 
                    className="max-h-64 rounded-lg mb-4"
                  />
                  <button 
                    className="text-blue-500 hover:text-blue-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedImage(null);
                    }}
                  >
                    Change Image
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex flex-col items-center">
                    <Upload className="w-12 h-12 mx-auto text-blue-400 mb-4" />
                    <p className="text-gray-600 mb-2">
                      {isDragging ? 'Drop your photo here' : 'Drag & drop a photo or click to upload'}
                    </p>
                    <p className="text-sm text-gray-400">Supports JPG, PNG, WEBP</p>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Generate Button */}
          <div className="flex justify-center mb-8">
            <button
              onClick={generateCaption}
              disabled={!selectedImage || isGenerating}
              className={`px-8 py-3 rounded-lg flex items-center transition duration-300 ${
                !selectedImage 
                  ? 'bg-gray-300 cursor-not-allowed' 
                  : 'bg-blue-500 hover:bg-blue-600 text-white'
              }`}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                'Generate Caption'
              )}
            </button>
          </div>

          {/* Caption Result */}
          {caption && (
            <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
              <div className="flex justify-end gap-2 mb-2">
                <button 
                  onClick={copyToClipboard}
                  className="p-1 text-blue-500 hover:text-blue-700 rounded hover:bg-blue-100"
                  title="Copy"
                >
                  <Copy size={16} />
                </button>
                <button 
                  onClick={handleEditClick}
                  className="p-1 text-blue-500 hover:text-blue-700 rounded hover:bg-blue-100"
                  title="Edit"
                >
                  <Edit size={16} />
                </button>
                <button
                  onClick={speakCaption}
                  className="p-1 text-blue-500 hover:text-blue-700 rounded hover:bg-blue-100"
                  title="Read Aloud"
                >
                  <Volume2 size={16} />
                </button>
              </div>
              
              {isEditing ? (
                <div className="space-y-2">
                  <textarea
                    value={editedCaption}
                    onChange={(e) => setEditedCaption(e.target.value)}
                    className="w-full p-2 border rounded"
                    rows="3"
                  />
                  <div className="flex justify-end space-x-2">
                    <button
                      onClick={handleCancelEdit}
                      className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveEdit}
                      className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
                    >
                      Save
                    </button>
                  </div>
                </div>
              ) : (
                <p className="text-gray-700 italic">{caption}</p>
              )}
            </div>
          )}
        </div>

        <div className="text-center text-gray-500 text-sm">
          <p>Our AI system performs comprehensive analysis of input images to generate contextually relevant captions.</p>
        </div>
      </div>
    </div>
  );
};

export default GenerateCaption;